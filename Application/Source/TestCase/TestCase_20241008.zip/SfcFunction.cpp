#include "TestCase.h"

#include "ConfigSetting.h"

const QString VEHICLE_TYPE_ICV = QString("ICV");
const QString VEHICLE_TYPE_EV = QString("EV");
const QString VEHICLE_TYPE_FCEV = QString("FCEV");
const QString VEHICLE_TYPE_PHEV = QString("PHEV");
const QString VEHICLE_TYPE_HEV = QString("HEV");

QSharedPointer<SfcFunction>& SfcFunction::instance() {
    static QSharedPointer<SfcFunction> gInstance;
    if (gInstance.isNull()) {
        gInstance = QSharedPointer<SfcFunction>(new SfcFunction());
    }
    return gInstance;
}

SfcFunction::SfcFunction() {
}

QString SfcFunction::isSfcFileInfo(const QString& signalName) {
    QString moduleName = QString();
    QStringList signalSplit = signalName.split(".");
    if (signalSplit.size() >= 2) {
        // signalName : SFC.{MODULE_NAME}.*
        moduleName = signalSplit.at(1);
        if ((moduleName.compare("Extension") == false) || (moduleName.compare("Private") == false)) {
            // signalName : SFC.Extension.{MODULE_NAME}.*  or  SFC.Private.{MODULE_NAME}.*
            moduleName = signalSplit.at(2);
        }
    } else {
        // signalName : {MODULE_NAME}
        moduleName = signalName;
    }
    QString sfcModelPath = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeSfcModelPath).toString();
    QStringList sfcTypeList = QStringList();
    int appMode = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeAppMode).toInt();
    bool appModePV = (appMode == ivis::common::AppModeEnum::AppModeTypePV);
    if (appModePV) {
        sfcTypeList = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeSfcSpecTypePV).toStringList();
    } else {
        sfcTypeList = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeSfcSpecTypeCV).toStringList();
        // Input Signal : SFC.ADAS_Driving_New.Telltale.FCA.Stat
        // Found Yml    : /model/SFC/ADAS_Driving_CV/ADAS_Driving_CV.yml
        // Module Name  : ADAS_Driving_New -> ADAS_Driving_CV
        // moduleName.remove("_New");
        moduleName.replace("_New", "_CV");
    }

    QString ymlFile = QString();
    for (const auto& sfc : sfcTypeList) {
        QString file = QString("%1/SFC/%2/%3/%4.yml").arg(sfcModelPath).arg(sfc).arg(moduleName).arg(moduleName);
        bool fileExists = QFile::exists(file);
        if (fileExists) {
            ymlFile = file;
        }
        // qDebug() << ((appModePV) ? ("\t PV yml :") : ("\t CV yml :")) << fileExists << file;

        if (appModePV == false) {
            file = QString("%1/SFC/%2/%3_CV/%4_CV.yml").arg(sfcModelPath).arg(sfc).arg(moduleName).arg(moduleName);
            if (QFile::exists(file)) {
                ymlFile = file;
                qDebug() << "\t -> yml :" << true << file;
            }
        }
    }
    // qDebug() << "Found yml :" << (ymlFile.size() > 0) << ymlFile;
    return ymlFile;
}

QStringList SfcFunction::isVsmFileInfo(const QString& vehicleName, const QStringList& specType) {
    QStringList fileName = QStringList();
    QString vsmPath = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeSfcModelPath).toString();
    vsmPath.append("/VSM");
    QString fileNameBase = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeVsmFileNameBaseCV).toString();
    int appMode = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeAppMode).toInt();
    if (appMode == ivis::common::AppModeEnum::AppModeTypePV) {
        fileNameBase = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeVsmFileNameBasePV).toString();
    }

    for (const auto& spec : specType) {
        if (vehicleName.compare("System") == false) {
            fileName.append(QString("%1/%2.%3.vsm").arg(vsmPath).arg(vehicleName).arg(spec));
        } else {
            fileName.append(QString("%1/%2").arg(vsmPath).arg(fileNameBase.arg(vehicleName).arg(spec)));
        }
    }
    return fileName;
}

QMap<int, QStringList> SfcFunction::isSignalDataInfo(const bool& isDataType, const QString& signalName,
                                                      const QStringList& signalData, const QMap<int, QStringList>& fileList) {
    const QString PREFIX_TYPE = QString("type:");
    const QString PREFIX_SIGNAL_NAME = QString("signalName:");
    const QString PREFIX_DATA_TYPE = QString("dataType:");
    const QString PREFIX_DESCRIPTION = QString("description:");
    const QString PREFIX_ABSTRACTION_NAME = QString("abstractionName:");
    const QString PREFIX_VALUE_ENUM = QString("valueEnum:");
    const QString PREFIX_MATCHING_TABLE = QString("matchingTable:");
    const QString PREFIX_CODE_COMMENTING = QString("# ");
    const QString PREFIX_HYPHEN = QString("-");
    const QString PREFIX_DOT = QString(".");
    const QString PREFIX_COLON = QString(":");
    const QString PREFIX_SPACE = QString(" ");
    // const QString PREFIX_MCAN = QString("_MCAN");
    // const QString PREFIX_CCAN = QString("_CCAN");

    QMap<int, QStringList> inputDataInfo = QMap<int, QStringList>();
    bool sfcSignal = signalName.trimmed().startsWith("SFC.");
    bool vehicleSignal = signalName.trimmed().startsWith("Vehicle.");

    if ((sfcSignal == false) && (vehicleSignal == false)) {
        qDebug() << "Input signal name is incorrect :" << signalName;
        return inputDataInfo;
    }

    QString signal = QString();
    bool vehicleSystem = signalName.contains("Vehicle.System.");
    int startAppendIndex = ((vehicleSystem) ? (3) : (2));
    int index = 0;
    for (const auto& splitText : signalName.split(PREFIX_DOT)) {
        if (index >= startAppendIndex) {
            signal.append((signal.size() > 0) ? (".") : (""));
            signal.append(splitText);
        }
        index++;
    }
    if (signal.size() == 0) {
        qDebug() << "Fail to signal name size : 0";
        return inputDataInfo;
    }

    // qDebug() << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
    // qDebug() << "Input  Signal      :" << signalName;
    // qDebug() << "Parser Signal      :" << signal;

    QMapIterator<int, QStringList> iter(fileList);
    while (iter.hasNext()) {
        iter.next();
        int inputDataType = iter.key();
        QStringList fileName = iter.value();
        // qDebug() << inputDataType << ". Size :" << fileName.size() << ", File :" << fileName;
        QString dataType = QString();
        QStringList valueEunm = QStringList();
        QStringList matchingTable = QStringList();
        for (const auto& file : fileName) {
            if (QFile::exists(file) == false) {
                // qDebug() << "\t\t Fail to file not exists :" << file;
                continue;
            }
            QStringList readData = ivis::common::FileInfo::readFile(file);
            QStringList vsmInfo = QStringList();
            bool foundSignal = false;
            for (QString lineStr : readData) {
                if (foundSignal) {
                    if ((lineStr.trimmed().startsWith(PREFIX_HYPHEN)) && (lineStr.trimmed().endsWith(PREFIX_COLON))) {
                        // if ((lineStr.contains(PREFIX_HYPHEN)) && (lineStr.contains(PREFIX_COLON))) {
                        // qDebug() << "\t Next  Signal[" << inputDataType << "] :" << lineStr;
                        break;
                    } else if ((lineStr.size() == 0) || (lineStr.contains(PREFIX_TYPE)) ||
                               // (lineStr.contains(PREFIX_DATA_TYPE)) ||   // Skip : dataType
                               (lineStr.contains(PREFIX_SIGNAL_NAME)) || (lineStr.contains(PREFIX_ABSTRACTION_NAME)) ||
                               (lineStr.contains(PREFIX_DESCRIPTION)) || (lineStr.contains(PREFIX_CODE_COMMENTING))) {
                        // Skip : type, signalName, description, abstractionName, #(주석)
                        continue;
                    } else {
                        // Append : ValueEnum, MatchingTable
                        lineStr.remove(PREFIX_SPACE);
                        vsmInfo.append(lineStr);
                    }
                } else {
                    if ((lineStr.contains(signal)) && (lineStr.contains(PREFIX_HYPHEN)) && (lineStr.contains(PREFIX_COLON))) {
                        // Input Signal : (Vehicle.Speed_Gauge.Output_DisplaySpeedUnit)
                        // Read  Signal : (- Speed_Gauge.Output_DisplaySpeedUnit:)
                        lineStr.remove(PREFIX_HYPHEN);
                        lineStr.remove(PREFIX_COLON);
                        lineStr.remove(PREFIX_SPACE);
                        foundSignal = ((sfcSignal) ? (true) : (lineStr.compare(signal) == false));
                        // qDebug() << ((foundSignal) ? ("\t Found") : ("\t Skip ")) << "Signal[" << inputDataType
                        //          << "] :" << lineStr;
                    }
                }
            }

            bool foundValueEnum = false;
            bool foundMatchingTable = false;
            bool foundDataType = false;
            for (const auto& info : vsmInfo) {
                if (info.contains(PREFIX_DATA_TYPE)) {
                    dataType = info;
                    dataType.remove(PREFIX_DATA_TYPE);
                    continue;
                }

                if (foundMatchingTable) {
                    foundValueEnum = false;
                    matchingTable.append(info);
                    // qDebug() << "\t MatchingTable :" << info;
                } else {
                    foundMatchingTable = (info.contains(PREFIX_MATCHING_TABLE));
                }

                if ((vehicleSystem) || (inputDataType == ivis::common::InputDataTypeEnum::InputDataTypeValueEnum)) {
                    if (foundValueEnum) {
                        if (info.contains(PREFIX_MATCHING_TABLE)) {
                            continue;
                        }
                        valueEunm.append(info);
                        // qDebug() << "\t ValueEnum     :" << info;
                    } else {
                        foundValueEnum = info.contains(PREFIX_VALUE_ENUM);
                    }
                }
            }
        }

        if (isDataType) {  // DataType prepend
            valueEunm.prepend(dataType);
            matchingTable.prepend(dataType);
        }

        if (inputDataType == ivis::common::InputDataTypeEnum::InputDataTypeValueEnum) {
            inputDataInfo[inputDataType] = valueEunm;
            // qDebug() << "\t Value    Size :" << valueEunm.size();
        } else {
            inputDataInfo[inputDataType] = matchingTable;
            // qDebug() << "\t Matching Size :" << matchingTable.size();
            if ((valueEunm.size() > 0) && (vehicleSystem)) {
                inputDataInfo[ivis::common::InputDataTypeEnum::InputDataTypeValueEnum] = valueEunm;
                // qDebug() << "\t Value    Size :" << valueEunm.size();
            }
        }
    }

    if (signalData.size() > 0) {
        inputDataInfo[ivis::common::InputDataTypeEnum::InputDataTypeInputData] = signalData;
    }
    // qDebug() << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n";

    return inputDataInfo;
}

QMap<int, QStringList> SfcFunction::isSignalFileList(const QString& signalName, const QString& vehicleType) {
    QMap<int, QStringList> fileList = QMap<int, QStringList>();

    if (signalName.trimmed().startsWith("SFC.")) {
        fileList[ivis::common::InputDataTypeEnum::InputDataTypeValueEnum].append(isSfcFileInfo(signalName));
    } else if (signalName.trimmed().startsWith("Vehicle.")) {
        QStringList typeList = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeSfcSpecTypeCV).toStringList();
        int appMode = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeAppMode).toInt();
        if (appMode == ivis::common::AppModeEnum::AppModeTypePV) {
            typeList = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeSfcSpecTypePV).toStringList();
        }

        // ValueEnum
        fileList[ivis::common::InputDataTypeEnum::InputDataTypeValueEnum] = isVsmFileInfo(QString("SKEL"), typeList);

        // MatchinigTable : CV(ICV, EV, FCEV)        PV(ICV, EV, FCEV, PHEV, HEV)
        for (const auto& vehicle : vehicleType.split(", ")) {
            int inputDataType = 0;
            if (vehicle.compare(VEHICLE_TYPE_ICV) == false) {
                inputDataType = ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableICV;
            } else if (vehicle.compare(VEHICLE_TYPE_EV) == false) {
                inputDataType = ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableEV;
            } else if (vehicle.compare(VEHICLE_TYPE_FCEV) == false) {
                inputDataType = ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableFCEV;
            } else if (vehicle.compare(VEHICLE_TYPE_PHEV) == false) {
                inputDataType = ivis::common::InputDataTypeEnum::InputDataTypeMatchingTablePHEV;
            } else if (vehicle.compare(VEHICLE_TYPE_HEV) == false) {
                inputDataType = ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableHEV;
            } else {
                continue;
            }
            fileList[inputDataType] = isVsmFileInfo(vehicle, typeList);
        }

        // MatchinigTable : System
        // typeList = QStringList({"Config", "Engineering", "Extra", "Gateway", "HardWire", "Micom", "TP", "Undefined"});
        typeList = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeSystemTypePV).toStringList();
        fileList[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableSystem] = isVsmFileInfo(QString("System"), typeList);
    } else {
    }

    return fileList;
}

QMap<int, QStringList> SfcFunction::isTCNameDataInfo(const QString& tcName, const QString& result, const QList<int>& columnList,
                                                      const bool& convert, const bool& mergeInfoErase,
                                                      QList<QStringList>& convertData) {
    const QVariant excelMergeStart = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMergeStart);
    const QVariant excelMergeEnd = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMergeEnd);
    const QVariant excelMerge = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMerge);
    const int startIndex = (convert) ? (ivis::common::PropertyTypeEnum::PropertyTypeConvertSheetDescription)
                                     : (ivis::common::PropertyTypeEnum::PropertyTypeOriginSheetPrivates);
    const int endIndex = ivis::common::PropertyTypeEnum::PropertyTypeOriginSheetMax;

    QPair<int, int> tcNameRowInfo((-1), (-1));
    QPair<int, int> resultRowInfo((-1), (-1));
    int foundSheetIndex = 0;

    for (int sheetIndex = startIndex; sheetIndex < endIndex; ++sheetIndex) {
        int rowIndex = 0;
        for (const auto& rowDataList : getSheetData(sheetIndex).toList()) {
            QStringList rowData = rowDataList.toStringList();
            if (rowData.size() < (static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max))) {
                qDebug() << "Fail to sheet data list size :" << rowData.size();
                continue;
            }
            QString text = rowData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::TCName));
            if (text.contains(tcName)) {
                if (text.contains(excelMergeEnd.toString())) {
                    tcNameRowInfo = QPair<int, int>(tcNameRowInfo.first, rowIndex);
                } else  {
                    if (text.contains(excelMerge.toString()) == false) {
                        tcNameRowInfo = QPair<int, int>(rowIndex, rowIndex);
                    }
                }

                if (result.size() > 0) {
                    text = rowData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Result));
                    if (text.contains(result)) {
                        if (text.contains(excelMergeEnd.toString())) {
                            resultRowInfo = QPair<int, int>(resultRowInfo.first, rowIndex);
                        } else  {
                            if (text.contains(excelMerge.toString()) == false) {
                                resultRowInfo = QPair<int, int>(rowIndex, rowIndex);
                            }
                        }
                    }
                }
            }
            rowIndex++;
        }

        if ((tcNameRowInfo.first >= 0) && (tcNameRowInfo.second >= 0)) {
            foundSheetIndex = sheetIndex;
            break;
        }
    }

    if (foundSheetIndex == 0) {
        qDebug() << "Fail to found tcName :" << tcName;
        return QMap<int, QStringList>();
    }

    QMap<int, QStringList> tcNameDataInfo = QMap<int, QStringList>();
    QPair<int, int> rowInfo = (result.size() == 0) ? (tcNameRowInfo) : (resultRowInfo);
    int searchRowIndex = 0;
    QMap<int, QMap<int, QString>> tempTcNameDataInfo;

    qDebug() << "Found TCName :" << tcName << result << rowInfo;
    qDebug() << "RowInfo :" << tcNameRowInfo << resultRowInfo;

    const auto sheetData = getSheetData(foundSheetIndex).toList();
    for (const auto& rowDataList : sheetData) {
        QVariantList rowData = rowDataList.toList();
        if ((searchRowIndex >= rowInfo.first) && (searchRowIndex <= rowInfo.second)) {
            QMap<int, QString> columnData;
            for (const auto& columnIndex : columnList) {
                if ((result.size() > 0) && (columnIndex == static_cast<int>(ivis::common::ExcelSheetTitle::Other::Result))) {
                    // Skip - [reulst value valid] & [columnList contains Result]
                    continue;
                }
                QString dataInfo = rowData.at(columnIndex).toString();
                if (mergeInfoErase) {
                    dataInfo.remove(excelMergeStart.toString());
                    dataInfo.remove(excelMergeEnd.toString());
                    dataInfo.remove(excelMerge.toString());
                }
                tcNameDataInfo[columnIndex].append(dataInfo);
                tcNameDataInfo[columnIndex].removeAll("");
                tcNameDataInfo[columnIndex].removeDuplicates();

                columnData[columnIndex] = dataInfo;
            }

            tempTcNameDataInfo[searchRowIndex] = columnData;
        }
        searchRowIndex++;
    }

    QList<QStringList> foundRowData;
    for (auto iter = tempTcNameDataInfo.cbegin(); iter != tempTcNameDataInfo.cend(); ++iter) {
        QStringList dataInfo(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max));
        for (auto iterData = iter.value().cbegin(); iterData != iter.value().cend(); ++iterData) {
            int columnIndex = iterData.key();
            if (columnIndex < static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max)) {
                dataInfo[columnIndex] = iterData.value();
            }
        }
        foundRowData.append(dataInfo);
    }

    bool appendState = false;
    QList<QStringList> tempList;
    QList<QStringList> rowData = convertData;
    convertData.clear();

    for (auto& foundRowInfo : foundRowData) {
        QString caseInfo = foundRowInfo.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Case));
        if (caseInfo.contains(excelMergeStart.toString())) {
            tempList.append(foundRowInfo);
        } else if (caseInfo.contains(excelMerge.toString())) {
            tempList.append(foundRowInfo);
        } else if (caseInfo.contains(excelMergeEnd.toString())) {
            tempList.append(foundRowInfo);
            appendState = true;
        } else {
            if (foundRowData.size() == 1) {
                if (rowData.size() == 0) {
                    convertData.append(rowData + foundRowData);
                    break;
                } else {
                    tempList.append(foundRowInfo);
                    appendState = true;
                }
            }
        }

        if (appendState) {
            appendState = false;
            for (auto& rowInfo : rowData) {
                QString rowSignalInfo = rowInfo.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputSignal));
                auto iter = std::remove_if(tempList.begin(), tempList.end(),
                                           [&](const QStringList& row) { return row.contains(rowSignalInfo); });
                tempList.erase(iter, tempList.end());
            }

            tempList = rowData + tempList;
            caseInfo.remove(excelMergeStart.toString());
            caseInfo.remove(excelMergeEnd.toString());
            caseInfo.remove(excelMerge.toString());

            for (int index = 0; index < tempList.size(); ++index) {
                QString mergeText;
                if (index == 0) {
                    mergeText = excelMergeStart.toString();
                } else if (index == (tempList.size() - 1)) {
                    mergeText = excelMergeEnd.toString();
                } else {
                    mergeText = excelMerge.toString();
                }
                tempList[index][static_cast<int>(ivis::common::ExcelSheetTitle::Other::Case)] = (mergeText + caseInfo);
            }
            convertData.append(tempList);
            tempList.clear();
        }
    }

#if 0
    qDebug() << "\n\n\n >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
    qDebug() << "========================================================================================";
    qDebug() << "isTCNameDataInfo :" << tcName << result << ", ColumnIndex :" << columnList;
    qDebug() << "\t ========================================================================================";
    for (const auto& dataInfo : rowData) {
        qDebug() << "\t RowInfo     :" << dataInfo;
    }
    qDebug() << "\t ========================================================================================";
    for (const auto& dataInfo : foundRowData) {
        qDebug() << "\t FoundInfo   :" << dataInfo;
    }
    qDebug() << "\t ========================================================================================";
    for (const auto& dataInfo : convertData) {
        qDebug() << "\t ConvertInfo :" << dataInfo;
    }
    qDebug() << "========================================================================================";

#if 0
    qDebug() << "isTCNameDataInfo :" << tcName << result << ", ColumnIndex :" << columnList;
    qDebug() << "Sheet :" << foundSheetIndex;
    qDebug() << "RowInfo[TCName] :" << tcNamerowInfo.first << tcNamerowInfo.second;
    qDebug() << "RowInfo[Result] :" << resultRowInfo.first << resultRowInfo.second;
    qDebug() << "TCNameDataInfo  :" << tcName << result;
    qDebug() << "RowData         :" << rowData;
    qDebug() << "FoundData       :" << foundRowData;
    qDebug() << "ConvertData     :" << convertData;
#endif
    qDebug() << "\n <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n";
#endif

    return tcNameDataInfo;
}

QPair<int, int> SfcFunction::isContainsRowInfo(const int& sheetIndex, const QString& tcName, const QString& result) {
    const QVariant excelMergeStart = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMergeStart);
    const QVariant excelMergeEnd = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMergeEnd);
    const QVariant excelMerge = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMerge);

    QPair<int, int> tcNameRowInfo((-1), (-1));
    QPair<int, int> resultRowInfo((-1), (-1));
    int rowIndex = 0;

    for (const auto& rowDataList : getSheetData(sheetIndex).toList()) {
        QStringList rowData = rowDataList.toStringList();
        if (rowData.size() < (static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max))) {
            // qDebug() << "Fail to sheet data list size :" << rowData.size();
            continue;
        }
        QString text = rowData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::TCName));
        if (text.contains(tcName)) {
            if (text.contains(excelMergeEnd.toString())) {
                tcNameRowInfo = QPair<int, int>(tcNameRowInfo.first, rowIndex);
            } else  {
                if (text.contains(excelMerge.toString()) == false) {
                    tcNameRowInfo = QPair<int, int>(rowIndex, rowIndex);
                }
            }

            if (result.size() > 0) {
                text = rowData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Result));
                if (text.contains(result)) {
                    if (text.contains(excelMergeEnd.toString())) {
                        resultRowInfo = QPair<int, int>(resultRowInfo.first, rowIndex);
                    } else  {
                        if (text.contains(excelMerge.toString()) == false) {
                            resultRowInfo = QPair<int, int>(rowIndex, rowIndex);
                        }
                    }
                }
            }
        }
        rowIndex++;
    }

    QPair<int, int> rowInfo = (result.size() == 0) ? (tcNameRowInfo) : (resultRowInfo);
    return rowInfo;
}

QList<QStringList> SfcFunction::isRowDataInfo(const int& sheetIndex, const QPair<int, int>& rowInfo,
                                                 const QPair<int, int>& columnInfo) {
    const int columnStart = columnInfo.first;
    const int columnEnd = columnInfo.second + 1;

    QList<QStringList> dataInfo;
    int columnMax = static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max);

    if ((sheetIndex == ivis::common::PropertyTypeEnum::PropertyTypeOriginSheetDescription) ||
        (sheetIndex < ivis::common::PropertyTypeEnum::PropertyTypeConvertSheetDescription)) {
        columnMax = static_cast<int>(ivis::common::ExcelSheetTitle::Description::Max);
    }

    qDebug() << "isRowDataInfo :" << sheetIndex << rowInfo << columnInfo;

    int rowIndex = 0;
    for (const auto& rowDataList : getSheetData(sheetIndex).toList()) {
        QStringList rowData = rowDataList.toStringList();
        if (rowData.size() < columnMax) {
            // qDebug() << "Fail to sheet data list size :" << rowData.size();
            continue;
        }

        QStringList data(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max));
        for (int columnIndex = columnStart; columnIndex < columnEnd; ++columnIndex) {
            data[columnIndex] = rowData[columnIndex];
        }

        if ((rowIndex >= rowInfo.first) && (rowIndex <= rowInfo.second)) {
            dataInfo.append(data);
            if (rowIndex == rowInfo.second) {
                break;
            }
        }
        rowIndex++;
    }

    return dataInfo;
}

QList<QStringList> SfcFunction::isDataInfo(const int& sheetIndex, const QString& tcName, const QString& result,
                                            const QPair<int, int>& columnInfo, const int& checkColumnIndex) {
    QList<QStringList> dataInfo;
    QPair<int, int> rowInfo = isContainsRowInfo(sheetIndex, tcName, result);

    if ((rowInfo.first >= 0) && (rowInfo.second >= 0)) {
        dataInfo = isRowDataInfo(sheetIndex, rowInfo, columnInfo);
    }

    if (checkColumnIndex > 0) {    // signal data : null -> remove
        QList<QStringList> tempDataInfo;
        for (auto& info : dataInfo) {
            if (info.size() < checkColumnIndex) {
                // qDebug() << "Fail to sheet data list size :" << rowData.size();
                continue;
            }

            QString signal = info.at(checkColumnIndex);
            if (signal.size() > 0) {
                tempDataInfo.append(info);
            }
        }
        dataInfo = tempDataInfo;
    }

    return dataInfo;
}

QList<QStringList> SfcFunction::isInputDataInfo(const int& sheetIndex, const QString& tcName, const QString& result) {
    const QPair<int, int> columnInfo(static_cast<int>(ivis::common::ExcelSheetTitle::Other::TCName),
                                     static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputData));
    QList<QStringList> dataInfo = isDataInfo(sheetIndex, tcName, result, columnInfo, 0);

    if (dataInfo.size() > 0) {
        qDebug() << "\t isInputDataInfo :" << dataInfo;
        qDebug() << "\n";
    }

    return dataInfo;
}

QList<QStringList> SfcFunction::isOutputDataInfo(const int& sheetIndex, const QString& tcName, const QString& result) {
    const QPair<int, int> columnInfo(static_cast<int>(ivis::common::ExcelSheetTitle::Other::OutputSignal),
                                     static_cast<int>(ivis::common::ExcelSheetTitle::Other::OutputValue));
    QList<QStringList> dataInfo = isDataInfo(sheetIndex, tcName, result, columnInfo, columnInfo.first);

    if (dataInfo.size() > 0) {
        qDebug() << "\t isOutputDataInfo :" << dataInfo;
        qDebug() << "\n";
    }

    return dataInfo;
}

QList<QStringList> SfcFunction::isConfigDataInfo(const int& sheetIndex, const QString& tcName, const QString& result) {
    const QPair<int, int> columnInfo(static_cast<int>(ivis::common::ExcelSheetTitle::Other::ConfigSignal),
                                     static_cast<int>(ivis::common::ExcelSheetTitle::Other::Data));
    QList<QStringList> dataInfo = isDataInfo(sheetIndex, tcName, result, columnInfo, columnInfo.first);

    if (dataInfo.size() == 0) {
        int descSheetIndex = ivis::common::PropertyTypeEnum::PropertyTypeOriginSheetDescription;
        if ((sheetIndex >= ivis::common::PropertyTypeEnum::PropertyTypeConvertSheetDescription) &&
            (sheetIndex < ivis::common::PropertyTypeEnum::PropertyTypeConvertSheetMax)) {
            descSheetIndex = ivis::common::PropertyTypeEnum::PropertyTypeConvertSheetDescription;
        }

        QPair<int, int> descRowInfo(0, 1);
        QPair<int, int> descColumnInfo(static_cast<int>(ivis::common::ExcelSheetTitle::Description::ConfigSignal),
                                        static_cast<int>(ivis::common::ExcelSheetTitle::Description::Data));
        QList<QStringList> descDataInfo = isRowDataInfo(descSheetIndex, descRowInfo, descColumnInfo);
        for (const auto& descData : descDataInfo) {
            QStringList data(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max));
            QString configSignal = descData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Description::ConfigSignal));
            QString configData = descData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Description::Data));

            data[static_cast<int>(ivis::common::ExcelSheetTitle::Description::ConfigSignal)] = configSignal;
            data[static_cast<int>(ivis::common::ExcelSheetTitle::Description::Data)] = configData;
            dataInfo.append(data);
        }
    }

    if (dataInfo.size() > 0) {
        qDebug() << "\t isConfigDataInfo :" << dataInfo;
        qDebug() << "\n";
    }

    return dataInfo;
}

QMap<QString, int> SfcFunction::isKeywordPatternInfo(const int& columnIndex) {
    QMap<QString, int> keywordPattern = QMap<QString, int>();

    if (columnIndex == static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputSignal)) {
        keywordPattern = {
            {"[Sheet]", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Sheet)},
            // {"[DependentOn]", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::DependentOn)},  // 추후 구현
            {"Other", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Other)},
        };
    } else if (columnIndex == static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputData)) {
        keywordPattern = {
            // {"[Cal]", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Cal)},
            // {"[NotTrigger]", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::NotTrigger)},
            // {"[Preset]", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Preset)},
            {"ValueChanged", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::ValueChanged)},
            {"~", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Range)},
            {"=", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Equal)},
            {">", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Over)},
            {"<", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Under)},
            {"=>", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Flow)},  // => 와 >= 가 함께 있을 때, 추후 구현
            {"!", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Not)},
            {"D`", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::DontCare)},
            {"Timeout", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Timeout)},
            {"Crc", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Crc)},
        };
    } else if (columnIndex == static_cast<int>(ivis::common::ExcelSheetTitle::Other::OutputSignal)) {
        keywordPattern = {
            {"[Sheet]", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Sheet)},
            {"Collect", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Collect)},
        };
    } else if (columnIndex == static_cast<int>(ivis::common::ExcelSheetTitle::Other::OutputValue)) {
        keywordPattern = {
            {"[Cal]", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Cal)},
        };
    } else if (columnIndex == static_cast<int>(ivis::common::ExcelSheetTitle::Other::ConfigSignal)) {
        keywordPattern = {
            {"|", static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Or)},
        };
    } else {
    }

    return keywordPattern;
}

int SfcFunction::isKeywordType(const int& columnIndex, QString& signalName) {
    int keywordType = static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Invalid);
    QMap<QString, int> keywordPattern = isKeywordPatternInfo(columnIndex);
    QString keywordText = signalName;

    for (auto iter = keywordPattern.constBegin(); iter != keywordPattern.constEnd(); ++iter) {
        QString text = iter.key();
        if (text.compare("Value Changed", Qt::CaseInsensitive) == 0) {
            text.trimmed();
        }
        bool compareState =
            ((text.compare("Timeout", Qt::CaseInsensitive) == 0) || (text.compare("Crc", Qt::CaseInsensitive) == 0) ||
             (text.compare("Collect", Qt::CaseInsensitive) == 0) || (text.compare("ValueChanged", Qt::CaseInsensitive) == 0));
        if (compareState) {
            if (keywordText.compare(text, Qt::CaseInsensitive) == 0) {
                keywordType |= iter.value();
            }
        } else {
            if (keywordText.contains(text, Qt::CaseInsensitive)) {
                keywordText.remove(text);
                keywordType |= iter.value();
            }
        }
    }

    if (keywordType != static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Invalid)) {
        // qDebug() << "isKeywordType :" << keywordType << ", Text :" << signalName << "->" << keywordText;
        signalName = keywordText;
    }

    return keywordType;
}

QList<KeywordInfo> SfcFunction::isKeywordTypeInfo(const int& sheetIndex) {
    const QVariant excelMergeStart = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMergeStart);
    const QVariant excelMergeEnd = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMergeEnd);
    const QVariant excelMerge = ConfigSetting::instance().data()->readConfig(ConfigInfo::ConfigTypeExcelMerge);
    const QList<int> columnList = QList({
        static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputSignal),
        static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputData),
        static_cast<int>(ivis::common::ExcelSheetTitle::Other::OutputSignal),
        static_cast<int>(ivis::common::ExcelSheetTitle::Other::OutputValue),
        // static_cast<int>(ivis::common::ExcelSheetTitle::Other::ConfigSignal),
    });

    QList<KeywordInfo> keywordInfo;
    int rowIndex = 0;
    QList<QPair<int, int>> caseRowInfo;
    QPair<int, int> rowInfo = QPair<int, int>((-1), (-1));

    for (const auto& rowDataList : getSheetData(sheetIndex).toList()) {
        QStringList rowData = rowDataList.toStringList();
        if (rowData.size() < (static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max))) {
            // qDebug() << "Fail to sheet data list size :" << rowData.size();
            continue;
        }

        for (const auto& columnIndex : columnList) {
            QString text = rowData.at(columnIndex);
            int keywordType = isKeywordType(columnIndex, text);
            QString data = QString();

            if (keywordType == static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Invalid)) {
                continue;
            }

            if (keywordType & static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Sheet)) {
                data = rowData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputData));
            } else if (keywordType & static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Range)) {
                data = rowData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputSignal));
            } else if (keywordType & static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Other)) {
                text = QString("Other");
            } else if (keywordType & (static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Under) |
                                      static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Equal))) {
                // [Cal][Sheet] 키워드에 대한 동작 처리
            } else {
            }
            keywordInfo.append(KeywordInfo(rowIndex, columnIndex, text, keywordType, data));
        }

        QString caseText = rowData.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Case));

        if (caseText.contains(excelMergeStart.toString())) {
            rowInfo = QPair<int, int>(rowIndex, (-1));
        } else if (caseText.contains(excelMergeEnd.toString())) {
            rowInfo = QPair<int, int>(rowInfo.first, rowIndex);
        } else {
        }

        if ((rowInfo.first >= 0) && (rowInfo.second >= 0)) {
            caseRowInfo.append(rowInfo);
            rowInfo = QPair<int, int>((-1), (-1));
        }

        rowIndex++;
    }

    for (auto& keyword : keywordInfo) {
        if ((keyword.isKeyword() & static_cast<int>(ivis::common::KeywordTypeEnum::KeywordType::Sheet)) == false) {
            continue;
        }

        QPair<int, int> rowInfo = QPair<int, int>((-1), (-1));
        for (const auto& row : caseRowInfo) {
            if ((keyword.isRow() < row.first) || (keyword.isRow() > row.second)) {
                continue;
            }
            rowInfo = row;
            break;
        }

        QList<QStringList> rowData;
        int getRowIndex = 0;
        const auto sheetData = getSheetData(sheetIndex).toList();
        for (const auto& rowDataList : sheetData) {
            if ((getRowIndex >= rowInfo.first) && (getRowIndex <= rowInfo.second)) {
                QStringList rowInfo = rowDataList.toStringList();
                QString inputSignalInfo = rowInfo.at(static_cast<int>(ivis::common::ExcelSheetTitle::Other::InputSignal));
                if (inputSignalInfo.contains(keyword.isText()) == false) {
                    QStringList dataInfo(static_cast<int>(ivis::common::ExcelSheetTitle::Other::Max));
                    QPair<int, int> indexInfo(static_cast<int>(ivis::common::ExcelSheetTitle::Other::TCName),
                                              static_cast<int>(ivis::common::ExcelSheetTitle::Other::OutputSignal));
                    for (int index = indexInfo.first; index < indexInfo.second; ++index) {
                        dataInfo[index] = rowInfo.at(index);
                    }
                    rowData.append(dataInfo);
                }
            }
            getRowIndex++;
        }
        keyword.updateRowData(rowData);
    }

#if 0
    for (const auto& keyword : keywordInfo) {
        qDebug() << "-----------------------------------------------------------------------------------------";
        qDebug() << "Keyword[" << sheetIndex << "]";
        qDebug() << "\t Info        :" << keyword.isRow() << keyword.isColumn() << keyword.isKeyword() << keyword.isText();
        qDebug() << "\t Data        :" << keyword.isData();
        qDebug() << "\t RowData     :" << keyword.isRowData();
        qDebug() << "\t ConvertData :" << keyword.isConvertData();
    }
#endif

    return keywordInfo;
}
