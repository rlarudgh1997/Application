#ifndef TEST_CASE_CLASS_H
#define TEST_CASE_CLASS_H

#include <QObject>

#include "CommonEnum.h"
#include "CommonUtil.h"

class KeywordInfo {
public:
    KeywordInfo() {
    }
    KeywordInfo(const int& row, const int& column, const QString& text, const int& keyword, const QString& data)
        : mRow(row), mColumn(column), mText(text), mKeyword(keyword), mData(data) {
    }
    int isRow() const {
        return mRow;
    }
    int isColumn() const {
        return mColumn;
    }
    QString isText() const {
        return mText;
    }
    int isKeyword() const {
        return mKeyword;
    }
    QString isData() const {
        return mData;
    }
    QList<QStringList> isRowData() const {
        return mRowData;
    }
    void updateRowData(const QList<QStringList>& rowData) {
        mRowData = rowData;
    }
    QList<QStringList> isConvertData() const {
        return mConvertData;
    }
    void updateConvertData(const QList<QStringList>& convertData) {
        mConvertData = convertData;
    }

private:
    int mRow = 0;
    int mColumn = 0;
    QString mText = QString();
    int mKeyword = 0;
    QString mData = QString();
    QList<QStringList> mConvertData = QList<QStringList>();
    QList<QStringList> mRowData = QList<QStringList>();
};

class SignalDataInfo : public QObject {
    Q_OBJECT

    REGISTER_WRITABLE_PROPERTY(int, KeywordType, 0, false)
    REGISTER_WRITABLE_PROPERTY(QString, DataType, QString(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, InputData, QStringList(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, ValueEnum, QStringList(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, MatchingTableICV, QStringList(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, MatchingTableEV, QStringList(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, MatchingTableFCEV, QStringList(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, MatchingTablePHEV, QStringList(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, MatchingTableHEV, QStringList(), false)
    REGISTER_WRITABLE_PROPERTY(QStringList, MatchingTableSystem, QStringList(), false)

public:
    SignalDataInfo() {
    }
    explicit SignalDataInfo(const QVariantList& dataInfo, const int& keywordType, const QString& dataType) {
        if (dataInfo.size() == (ivis::common::InputDataTypeEnum::InputDataTypeMax - 1)) {
            QMap<int, QStringList> info;
            info[ivis::common::InputDataTypeEnum::InputDataTypeValueEnum] = dataInfo.at(0).toStringList();
            info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableICV] = dataInfo.at(1).toStringList();
            info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableEV] = dataInfo.at(2).toStringList();
            info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableFCEV] = dataInfo.at(3).toStringList();
            info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTablePHEV] = dataInfo.at(4).toStringList();
            info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableHEV] = dataInfo.at(5).toStringList();
            info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableSystem] = dataInfo.at(6).toStringList();
            info[ivis::common::InputDataTypeEnum::InputDataTypeInputData] = dataInfo.at(7).toStringList();
            updateSignalDataInfo(info, keywordType, dataType);
        }
    }
    explicit SignalDataInfo(const QMap<int, QStringList>& dataInfo, const int& keywordType, const QString& dataType) {
        updateSignalDataInfo(dataInfo, keywordType, dataType);
    }
    int isDataType() {
        int dataType = static_cast<int>(ivis::common::DataTypeEnum::DataType::Invalid);
        QString isDataType = getDataType();

        if (isDataType.compare("HUInt64") == false) {
            dataType = static_cast<int>(ivis::common::DataTypeEnum::DataType::HUInt64);
        } else if (isDataType.compare("HInt64") == false) {
            dataType = static_cast<int>(ivis::common::DataTypeEnum::DataType::HInt64);
        } else if (isDataType.compare("HString") == false) {
            dataType = static_cast<int>(ivis::common::DataTypeEnum::DataType::HString);
        } else {
        }

        return dataType;
    }

private:
    void updateSignalDataInfo(const QMap<int, QStringList>& dataInfo, const int& keywordType, const QString& dataType) {
        QMap<int, QStringList> info = dataInfo;

        if (info.size() > 0) {
            // DataType Update : dataType or ValueEnum[0]
            if (dataType.size() == 0) {
                auto valueEnum = info[ivis::common::InputDataTypeEnum::InputDataTypeValueEnum];
                if (valueEnum.size() > 0) {
                    setDataType(valueEnum.at(0));
                }
            } else {
                setDataType(dataType);
            }

            // DataType Remove : MatchingTable*[0] -> Not Used
            for (int index = ivis::common::InputDataTypeEnum::InputDataTypeValueEnum;
                 index < ivis::common::InputDataTypeEnum::InputDataTypeMax; ++index) {
                if ((info[index].size() > 0) && (index != ivis::common::InputDataTypeEnum::InputDataTypeInputData)) {
                    info[index].removeAt(0);
                }
            }
        }
        setKeywordType(keywordType);
        setValueEnum(info[ivis::common::InputDataTypeEnum::InputDataTypeValueEnum]);
        setMatchingTableICV(info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableICV]);
        setMatchingTableEV(info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableEV]);
        setMatchingTableFCEV(info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableFCEV]);
        setMatchingTablePHEV(info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTablePHEV]);
        setMatchingTableHEV(info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableHEV]);
        setMatchingTableSystem(info[ivis::common::InputDataTypeEnum::InputDataTypeMatchingTableSystem]);
        setInputData(info[ivis::common::InputDataTypeEnum::InputDataTypeInputData]);
    }
};

#endif  // TEST_CASE_CLASS_H
