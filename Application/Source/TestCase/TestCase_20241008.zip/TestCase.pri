INCLUDEPATH += \
    $$PWD\


DEFINES += __TEST_CASE__


HEADERS += \
    $$PWD/TestCase.h\
    $$PWD/TestCaseClass.h\
    $$PWD/SfcFunction.h\


SOURCES += \
    $$PWD/TestCase.cpp\
    $$PWD/SfcFunction.cpp\
