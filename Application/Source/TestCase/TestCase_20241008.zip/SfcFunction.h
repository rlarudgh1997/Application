#ifndef SFC_FUNCTION_H
#define SFC_FUNCTION_H

#include <QObject>

#include "CommonUtil.h"
#include "CommonEnum.h"
#include "TestCaseClass.h"

class SfcFunction : public QObject {
public:
    static QSharedPointer<TestCase>& instance();

    QString isSfcFileInfo(const QString& signalName);
    QStringList isVsmFileInfo(const QString& vehicleName, const QStringList& specType);
    QMap<int, QStringList> isSignalDataInfo(const bool& isDataType, const QString& signalName, const QStringList& signalData,
                                            const QMap<int, QStringList>& fileList);
    QMap<int, QStringList> isSignalFileList(const QString& signalName, const QString& vehicleType);
    QMap<int, QStringList> isTCNameDataInfo(const QString& tcName, const QString& result, const QList<int>& columnList,
                                            const bool& convert, const bool& mergeInfoErase, QList<QStringList>& convertData);
    QPair<int, int> isContainsRowInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QList<QStringList> isRowDataInfo(const int& sheetIndex, const QPair<int, int>& rowInfo, const QPair<int, int>& columnInfo);
    QList<QStringList> isDataInfo(const int& sheetIndex, const QString& tcName, const QString& result,
                                       const QPair<int, int>& columnInfo, const int& checkColumnIndex = 0);
    QList<QStringList> isInputDataInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QList<QStringList> isOutputDataInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QList<QStringList> isConfigDataInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QMap<QString, int> isKeywordPatternInfo(const int& columnIndex);
    int isKeywordType(const int& columnIndex, QString& signalName);
    QList<KeywordInfo> isKeywordTypeInfo(const int& sheetIndex);

private:
    explicit SfcFunction();
};

#endif  // SFC_FUNCTION_H
