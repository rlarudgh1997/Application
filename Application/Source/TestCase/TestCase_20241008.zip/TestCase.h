#ifndef TEST_CASE_H
#define TEST_CASE_H

#include <QObject>

#include "CommonUtil.h"
#include "CommonEnum.h"
#include "TestCaseClass.h"

class TestCase : public QObject {
    REGISTER_WRITABLE_PROPERTY(int, ExcuteType, 0, false)
    REGISTER_WRITABLE_PROPERTY_CONTAINER2(QMap, int, QVariant, SheetData, false)

public:
    enum {
        ExcuteTypeInvalid = 0,
        ExcuteTypeGenTC,
        ExcuteTypeRunTC,
    };

public:
    static QSharedPointer<TestCase>& instance();

    void excuteTestCase(const int& type = ExcuteTypeGenTC);
    int isKeywordType(const QString& signalName);
    int isDataType(QMap<int, QStringList>& dataInfo, const int& keywordType);
    void clearSignalDataInfo(const QString& signalName = QString());
    void setSignalDataInfo(const QString& signalName, const QMap<int, QStringList>& dataInfo, const int& keywordType,
                           const QString& dataType = QString());
    QMap<int, QStringList> getSignalDataInfo(const QString& signalName, int& keywordType, QString& dataType);
    QString getSignalInfoString();


    QString isSfcFileInfo(const QString& signalName);
    QStringList isVsmFileInfo(const QString& vehicleName, const QStringList& specType);
    QMap<int, QStringList> isSignalDataInfo(const bool& isDataType, const QString& signalName, const QStringList& signalData,
                                            const QMap<int, QStringList>& fileList);
    QMap<int, QStringList> isSignalFileList(const QString& signalName, const QString& vehicleType);
    QMap<int, QStringList> isTCNameDataInfo(const QString& tcName, const QString& result, const QList<int>& columnList,
                                            const bool& convert, const bool& mergeInfoErase, QList<QStringList>& convertData);
    QPair<int, int> isContainsRowInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QList<QStringList> isRowDataInfo(const int& sheetIndex, const QPair<int, int>& rowInfo, const QPair<int, int>& columnInfo);
    QList<QStringList> isDataInfo(const int& sheetIndex, const QString& tcName, const QString& result,
                                       const QPair<int, int>& columnInfo, const int& checkColumnIndex = 0);
    QList<QStringList> isInputDataInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QList<QStringList> isOutputDataInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QList<QStringList> isConfigDataInfo(const int& sheetIndex, const QString& tcName, const QString& result);
    QMap<QString, int> isKeywordPatternInfo(const int& columnIndex);
    int isKeywordType(const int& columnIndex, QString& signalName);
    QList<KeywordInfo> isKeywordTypeInfo(const int& sheetIndex);
    bool replaceGenDataInfo();
    void constructGenDataInfo();

private:
    explicit TestCase();

private:
    QMap<QString, QSharedPointer<SignalDataInfo>> mSignalDataInfo = QMap<QString, QSharedPointer<SignalDataInfo>>();
};

#endif  // TEST_CASE_H
