#include "Service.h"

#include <regex>
#include <QDebug>

QSharedPointer<Service>& Service::instance() {
    static QSharedPointer<Service> gService;
    if (gService.isNull()) {
        gService = QSharedPointer<Service>(new Service());
    }
    return gService;
}

Service::Service() {
    qDebug() << "Service - Start";
}

void Service::init() {
    qDebug() << "Service - Init";

    getVehicleSignalModel();

    subscribeConstantSignals();
    subscribeTelltaleSignals();
    subscribeEventSignals();
    subscribeSoundSignals();
    subscribeEtcSignals();
}

ccos::vehicle::vsm::HVehicleSignalModel& Service::getVehicleSignalModel() {
    static ccos::vehicle::vsm::HVehicleSignalModel* gVehicleSignalModel = nullptr;
    if (gVehicleSignalModel == nullptr) {
        gVehicleSignalModel = new ccos::vehicle::vsm::HVehicleSignalModel;
    }
    return *gVehicleSignalModel;
}

void Service::addSubscription(const std::string& nodeAddress, const SignalHandlingFunc& handlingFunc) {
    auto subscription = std::make_shared<ccos::vehicle::vsm::HSubscription>(std::vector<std::string>{nodeAddress},
                                                                            ccos::vehicle::vsm::HSubscriptionType::VALUE_CHANGED,
                                                                            std::make_shared<VehicleListener>(handlingFunc));
    auto result = getVehicleSignalModel().subscribe(subscription);

    if (result != ccos::HResult::OK) {
        qDebug() << "Fail to subscribe :" << static_cast<int>(result) << nodeAddress.c_str();
    }
}

void Service::addSubscriptionGroup(const std::vector<std::string>& nodePaths, const SignalHandlingFunc& handlingFunc) {
    auto subscription = std::make_shared<ccos::vehicle::vsm::HSubscription>(
        nodePaths, ccos::vehicle::vsm::HSubscriptionType::VALUE_CHANGED, std::make_shared<VehicleListener>(handlingFunc));
    auto result = getVehicleSignalModel().subscribe(subscription);

    // qDebug() << "\t addSubscriptionGroup :" << ((result == ccos::HResult::OK) ? ("Success") : ("Fail"));
    if (result != ccos::HResult::OK) {
        for (const std::string& nodeAddress : nodePaths) {
            qDebug() << "Fail to subscribe :" << static_cast<int>(result) << nodeAddress.c_str();
        }
    }
}

QVariant Service::isConstantSignal(const Constant& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                                   QHash<QString, QVariant>& values) {
    QVariant value = QVariant("value not found");
    std::string nodePath = vehicleSignal.getNodePath();

    if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LongPos.Stat) {
        value = static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LongPos.Stat.value(vehicleSignal));
    } else if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LongPos.Value) {
        value = static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LongPos.Value.value(vehicleSignal));
    } else if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LatPos.Stat) {
        value = static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LatPos.Stat.value(vehicleSignal));
    } else if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LatPos.Value) {
        value = static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LatPos.Value.value(vehicleSignal));
    } else if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LongPos.Stat) {
        value = static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LongPos.Stat.value(vehicleSignal));
    } else if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LatPos.Value) {
        value = static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LatPos.Value.value(vehicleSignal));
    } else if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LatPos.Stat) {
        value = static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LatPos.Stat.value(vehicleSignal));
    } else if (nodePath == SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LongPos.Value) {
        value =
            static_cast<ccos::HUInt64>(SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LongPos.Value.value(vehicleSignal));
    } else {
    }

    if (nodePath.empty() == false) {
        values[nodePath.c_str()] = value;
    }
    qDebug() << "isConstantSignal :" << nodePath.c_str() << value;
    return value;
}

QVariant Service::isTelltaleSignal(const Telltale& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                                   QHash<QString, QVariant>& values) {
    return QVariant();
}

QVariant Service::isEventSignal(const Event& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                                QHash<QString, QVariant>& values) {
    return QVariant();
}

QVariant Service::isSoundSignal(const Sound& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                                QHash<QString, QVariant>& values) {
    return QVariant();
}

QVariant Service::isEtcSignal(const Etc& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                              QHash<QString, QVariant>& values) {
    return QVariant();
}

template <typename SignalType>
QVariant Service::processSignal(const DataType& dataType, const SignalType& type,
                                const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal, QHash<QString, QVariant>& values) {
    QVariant isValue = QVariant();

    switch (dataType) {
        case DataType::Constant:
            isValue = isConstantSignal(static_cast<Constant>(type), vehicleSignal, values);
            break;
        case DataType::Telltale:
            isValue = isTelltaleSignal(static_cast<Telltale>(type), vehicleSignal, values);
            break;
        case DataType::Event:
            isValue = isEventSignal(static_cast<Event>(type), vehicleSignal, values);
            break;
        case DataType::Sound:
            isValue = isSoundSignal(static_cast<Sound>(type), vehicleSignal, values);
            break;
        case DataType::Etc:
            isValue = isEtcSignal(static_cast<Etc>(type), vehicleSignal, values);
            break;
        default:
            break;
    }
    return isValue;
}

template <typename SignalType>
void Service::onSignalChanged(const SignalType& signalType, const std::vector<ccos::vehicle::vsm::HVehicleSignal>& signalList) {
    // 신호 변경 시 호출되는 콜백 함수 구현
    // 이 함수는 주어진 신호 리스트에 대해 반복하면서 processSignal을 호출하여 각 신호를 처리합니다.
    // 이 함수는 신호 타입과 신호 리스트를 받아서 처리합니다.
    // 각 신호에 대한 처리 로직은 processSignal에서 수행됩니다.
    // QHash<QString, QVariant> values;
    // for (const auto& vehicleSignal : signalList) {
    //     QVariant result = processSignal(signalType, vehicleSignal, values);
    //     // 필요한 경우 result를 사용하여 추가적인 작업을 수행할 수 있습니다.
    // }
    // 처리된 결과를 사용하여 추가적인 작업을 수행할 수 있습니다.
}

template <typename SignalType>
void Service::subscribeSignals(const DataType& dataType,
                               const std::vector<std::pair<SignalType, std::vector<std::string>>>& signalsToSubscribe) {
    for (const auto& signalPair : signalsToSubscribe) {
        const SignalType& type = signalPair.first;
        const std::vector<std::string>& nodePaths = signalPair.second;
        SignalHandlingFunc handlingFunc = [this, dataType,
                                           type](const std::vector<ccos::vehicle::vsm::HVehicleSignal>& vehicleSignals) {
            QHash<QString, QVariant> values;
            for (const auto& vehicleSignal : vehicleSignals) {
                QVariant result = processSignal(dataType, type, vehicleSignal, values);
            }
            emit signalServiceDatasChanged(static_cast<int>(dataType), static_cast<int>(type), values);
        };
        addSubscriptionGroup(nodePaths, handlingFunc);
    }
}

void Service::subscribeConstantSignals() {
    subscribeSignals<Constant>(
        DataType::Constant,
        {
            // {Constant::SpeedAnalogStat, {SFC.Speed_Gauge.Constant.SpeedAnalog.Stat}},
            // {Constant::SpeedAnalogValue, {SFC.Speed_Gauge.Constant.SpeedAnalog.Value}},
            // {Constant::SpeedDigitalStat, {SFC.Speed_Gauge.Constant.SpeedDigital.Stat}},
            // {Constant::SpeedDigitalValue, {SFC.Speed_Gauge.Constant.SpeedDigital.Value}},
            // {Constant::SpeedSubDigitalStat, {SFC.Speed_Gauge.Constant.SpeedSubDigital.Stat}},
            // {Constant::SpeedSubDigitalValue, {SFC.Speed_Gauge.Constant.SpeedSubDigital.Value}},
            // {Constant::SpeedMainDisplayUnitStat, {SFC.Speed_Gauge.Constant.SpeedMainDisplayUnit.Stat}},
            // {Constant::SpeedAuxDisplayUnitStat, {SFC.Speed_Gauge.Constant.SpeedAuxDisplayUnit.Stat}},
            // {Constant::SpeedSubDisplayStat, {SFC.Speed_Gauge.Constant.SpeedSubDisplay.Stat}},
            // {Constant::SpeedScaleMaximumStat, {SFC.Speed_Gauge.Constant.SpeedScaleMaximum.Stat}},
            // {Constant::NaviSpeedLimitStat, {SFC.Speed_Gauge.Constant.NaviSpeedLimit.Stat}},
            // {Constant::NaviSpeedLimitOver1ColorValue, {SFC.Speed_Gauge.Constant.NaviSpeedLimitOver1Color.Value}},
            // {Constant::NaviSpeedLimitOver2ColorValue, {SFC.Speed_Gauge.Constant.NaviSpeedLimitOver2Color.Value}},
            // {Constant::RpmValue, {SFC.Tachometer.Constant.Rpm.Value}},
            // {Constant::RedZoneExceptNbrandStat, {SFC.Tachometer.Constant.RedZoneExceptNbrand.Stat}},
            // {Constant::RedZoneNbrandStat, {SFC.Tachometer.Constant.RedZoneNbrand.Stat}},
            // {Constant::MaxRpmStat, {SFC.Tachometer.Constant.MaxRpm.Stat}},
            // {Constant::RpmDampStat, {SFC.Tachometer.Constant.RpmDamp.Stat}},
            // {Constant::ResvChargeStat, {SFC.Intro_Outro.Constant.ResvCharge.Stat}},
            // {Constant::ResvClimateStat, {SFC.Intro_Outro.Constant.ResvClimate.Stat}},
            // {Constant::PurificationAirStat, {SFC.Intro_Outro.Constant.PurificationAir.Stat}},
            // {Constant::PurificationAirValue, {SFC.Intro_Outro.Constant.PurificationAir.Value}},
            // {Constant::CO2ReductionStat, {SFC.Intro_Outro.Constant.CO2Reduction.Stat}},
            // {Constant::CO2ReductionValue, {SFC.Intro_Outro.Constant.CO2Reduction.Value}},
            // {Constant::OutTempDisplayStat, {SFC.OAT.Constant.OutTempDisplay.Stat}},
            // {Constant::OutTempDisplayUnitStat, {SFC.OAT.Constant.OutTempDisplayUnit.Stat}},
            {Constant::ViewFrontVehicle,
             {SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LongPos.Stat,
              SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LongPos.Value,
              SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LatPos.Stat,
              SFC.ADAS_Driving_New.Constant.ViewFrontLeftVehicle.LatPos.Value,
              SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LongPos.Stat,
              SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LatPos.Value,
              SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LatPos.Stat,
              SFC.ADAS_Driving_New.Constant.ViewFrontRightVehicle.LongPos.Value}},
        });
}

void Service::subscribeTelltaleSignals() {
    subscribeSignals<Telltale>(DataType::Telltale, {
                                                       // {Telltale::LampIndicator, {SFC.Telltale.LampIndicator.Node1,
                                                       // SFC.Telltale.LampIndicator.Node2}}, 다른 Telltale 신호들 추가
                                                   });
}

void Service::subscribeEventSignals() {
    subscribeSignals<Event>(DataType::Event, {
                                                 // {Event::IntroOutro, {SFC.Event.IntroOutro.Node1, SFC.Event.IntroOutro.Node2}},
                                                 // 다른 Event 신호들 추가
                                             });
}

void Service::subscribeSoundSignals() {
    subscribeSignals<Sound>(DataType::Sound, {
                                                 // {Sound::LampIndicator, {SFC.Sound.LampIndicator.Node1,
                                                 // SFC.Sound.LampIndicator.Node2}}, 다른 Sound 신호들 추가
                                             });
}

void Service::subscribeEtcSignals() {
    subscribeSignals<Etc>(DataType::Etc, {
                                             // {Etc::SpeedGauge, {SFC.Etc.SpeedGauge.Node1, SFC.Etc.SpeedGauge.Node2}},
                                             // 다른 Etc 신호들 추가
                                         });
}
