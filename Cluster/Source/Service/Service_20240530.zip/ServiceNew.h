#ifndef SERIVCE_H
#define SERIVCE_H

#include <QObject>
#include <QSharedPointer>
#include <QVariant>

#include <HVehicleSignalModel.h>
#include <vsm.h>
#include "SFCHelper.h"
#include "ServiceEnum.h"

using SignalHandlingFunc = std::function<void(const std::vector<ccos::vehicle::vsm::HVehicleSignal>&)>;
using NodePathToValueFunc = std::function<QVariant(const ccos::vehicle::vsm::HVehicleSignal&)>;

class VehicleListener : public ccos::vehicle::vsm::IHSubscriptionListener {
public:
    explicit VehicleListener(const SignalHandlingFunc& handlingFunc) {
        mHandlingFunc = handlingFunc;
    }
    void onVehicleSignalReceived(const std::vector<ccos::vehicle::vsm::HVehicleSignal>& signalList) {
        mHandlingFunc(signalList);
    }
    void onVehicleSignalTimeout(const ccos::vehicle::vsm::HVehicleSignal& signal) {
    }

private:
    SignalHandlingFunc mHandlingFunc;
};

class Service : public QObject {
    Q_OBJECT

public:
    static QSharedPointer<Service>& instance();
    void init();

private:
    explicit Service();

    ccos::vehicle::vsm::HVehicleSignalModel& getVehicleSignalModel();
    void addSubscription(const std::string& nodeAddress, const SignalHandlingFunc& handlingFunc);
    void addSubscriptionGroup(const std::vector<std::string>& nodePaths, const SignalHandlingFunc& handlingFunc);

    QVariant isConstantSignal(const Constant& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                              QHash<QString, QVariant>& values);
    QVariant isTelltaleSignal(const Telltale& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                              QHash<QString, QVariant>& values);
    QVariant isEventSignal(const Event& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                           QHash<QString, QVariant>& values);
    QVariant isSoundSignal(const Sound& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                           QHash<QString, QVariant>& values);
    QVariant isEtcSignal(const Etc& type, const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal,
                         QHash<QString, QVariant>& values);

    template <typename SignalType>
    QVariant processSignal(const DataType& dataType, const SignalType& type,
                           const ccos::vehicle::vsm::HVehicleSignal& vehicleSignal, QHash<QString, QVariant>& values);

    template <typename SignalType>
    void onSignalChanged(const SignalType& signalType, const std::vector<ccos::vehicle::vsm::HVehicleSignal>& signalList);

    void subscribeConstantSignals();
    void subscribeTelltaleSignals();
    void subscribeEventSignals();
    void subscribeSoundSignals();
    void subscribeEtcSignals();

    template <typename SignalType>
    void subscribeSignals(const DataType& datatType,
                          const std::vector<std::pair<SignalType, std::vector<std::string>>>& signalsToSubscribe);

signals:
    void signalServiceDataChanged(const int& dataType, const int& signalType, const QVariant& signalValue);
    void signalServiceDatasChanged(const int& dataType, const int& signalType, const QHash<QString, QVariant>& signalValues);
};
#endif  // SERIVCE_H
